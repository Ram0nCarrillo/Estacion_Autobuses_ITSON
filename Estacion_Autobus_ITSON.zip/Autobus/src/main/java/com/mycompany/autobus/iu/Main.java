/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.autobus.iu;

import com.mycompany.autobus.entidades.Asiento;
import com.mycompany.autobus.entidades.Autobus;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Main extends JFrame {
    private Autobus autobus; // Instancia del autobús
    private JTextArea textArea; // Para mostrar el historial de compras
    private JComboBox<String> destinoComboBox; // Para seleccionar el destino
    private JPanel asientosPanel; // Panel donde se mostrarán los asientos
    private int asientoSeleccionado = -1; // Índice del asiento seleccionado para la compra

    public Main() {
        autobus = new Autobus(); // Crear la instancia del autobús

        // Configurar la ventana principal
        setTitle("Sistema de Autobús");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear componentes de la interfaz gráfica
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Panel para los asientos (cuadrados)
        asientosPanel = new JPanel(new GridLayout(2, 10, 10, 10));
        panel.add(new JLabel("Seleccione su asiento:"));
        panel.add(asientosPanel);

        // ComboBox para destinos
        destinoComboBox = new JComboBox<>(autobus.getDestinos());
        panel.add(new JLabel("Seleccione su destino:"));
        panel.add(destinoComboBox);

        // Área de texto para el historial de compras
        textArea = new JTextArea(10, 40);
        textArea.setEditable(false);
        JScrollPane historyScroll = new JScrollPane(textArea);
        panel.add(new JLabel("Historial de compras:"));
        panel.add(historyScroll);

        // Botones de acción
        JPanel buttonPanel = new JPanel();
        JButton comprarButton = new JButton("Comprar Asiento");
        comprarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comprarAsiento();
            }
        });
        buttonPanel.add(comprarButton);

        JButton comenzarViajeButton = new JButton("Comenzar Viaje");
        comenzarViajeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comenzarViaje();
            }
        });
        buttonPanel.add(comenzarViajeButton);

        // Agregar componentes a la ventana
        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Crear los asientos visualmente
        crearAsientos();
    }

    // Método para actualizar la representación gráfica de los asientos
    private void crearAsientos() {
        asientosPanel.removeAll(); // Limpiar el panel de asientos

        List<Asiento> asientos = autobus.getAsientos();
        for (int i = 0; i < asientos.size(); i++) {
            Asiento asiento = asientos.get(i);
            JButton botonAsiento = new JButton("Asiento " + (i + 1));
            botonAsiento.setPreferredSize(new Dimension(60, 60));
            botonAsiento.setBackground(asiento.estaComprado() ? Color.RED : Color.GREEN);

            // Acción cuando el usuario hace clic en un asiento
            final int asientoIndex = i;  // Hacer 'i' final para que se pueda usar en la clase interna
            botonAsiento.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    asientoSeleccionado = asientoIndex; // Asignar el índice de asiento seleccionado
                }
            });

            asientosPanel.add(botonAsiento);
        }

        asientosPanel.revalidate();
        asientosPanel.repaint();
    }

    // Método para comprar un asiento
    private void comprarAsiento() {
        if (asientoSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un asiento.");
            return;
        }

        // Pedir nombre del comprador
        String nombreComprador = JOptionPane.showInputDialog(this, "Ingrese su nombre:");

        if (nombreComprador == null || nombreComprador.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio.");
            return;
        }

        int numeroAsiento = asientoSeleccionado + 1;
        boolean comprado = autobus.comprarAsiento(numeroAsiento);

        if (comprado) {
            String destino = (String) destinoComboBox.getSelectedItem();
            int precio = autobus.getPrecioPorDestino(destino);
            String fechaHora = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());

            // Agregar al historial con nombre del comprador
            textArea.append("Nombre: " + nombreComprador + " - Asiento " + numeroAsiento + " comprado para " + destino + 
                             " por $" + precio + " - Fecha y hora: " + fechaHora + "\n");

            crearAsientos(); // Actualiza los asientos visualmente
        } else {
            JOptionPane.showMessageDialog(this, "El asiento ya ha sido comprado.");
        }
    }

    // Método para comenzar el viaje
    private void comenzarViaje() {
        JOptionPane.showMessageDialog(this, "¡Disfruta tu viaje!");

        int opcion = JOptionPane.showOptionDialog(this, "¿Deseas hacer otro viaje?", 
                                                    "Confirmar viaje", 
                                                    JOptionPane.YES_NO_OPTION, 
                                                    JOptionPane.QUESTION_MESSAGE, 
                                                    null, 
                                                    new Object[] {"Sí", "No"}, 
                                                    "Sí");

        if (opcion == JOptionPane.YES_OPTION) {
            autobus.resetAsientos(); // Resetea los asientos para el siguiente viaje
            textArea.setText(""); // Limpia el historial
            crearAsientos(); // Actualiza la visualización de los asientos
        } else {
            JOptionPane.showMessageDialog(this, "¡Que tenga un lindo día!");
            System.exit(0); // Cierra la aplicación
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Main mainWindow = new Main();
                mainWindow.setVisible(true);
            }
        });
    }
}