/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.autobus.entidades;

public class Asiento {
    private int numero; // Número del asiento
    private boolean comprado; // Estado del asiento: si está comprado o no

    public Asiento(int numero) {
        this.numero = numero;
        this.comprado = false;
    }

    public int getNumero() {
        return numero;
    }

    public boolean estaComprado() {
        return comprado;
    }

    public void comprar() {
        this.comprado = true;
    }

    public void setComprado(boolean comprado) {
        this.comprado = comprado;
    }
}