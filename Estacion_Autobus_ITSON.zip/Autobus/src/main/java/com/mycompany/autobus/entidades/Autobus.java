/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.autobus.entidades;

import java.util.ArrayList;
import java.util.List;

public class Autobus {
    private List<Asiento> asientos;
    private String[] destinos = {"Guaymas", "Obregón", "Hermosillo"};
    private int[] precios = {200, 250, 300};

    public Autobus() {
        asientos = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            asientos.add(new Asiento(i));
        }
    }
    
    public int getPrecioPorDestino(String destino) {
    int index = -1;
    for (int i = 0; i < destinos.length; i++) {
        if (destinos[i].equals(destino)) {
            index = i;
            break;
        }
    }
    return index != -1 ? precios[index] : 0; // Retorna el precio basado en el destino
}


    public List<Asiento> getAsientos() {
        return asientos;
    }

    public String[] getDestinos() {
        return destinos;
    }

    public int[] getPrecios() {
        return precios;
    }

    public boolean comprarAsiento(int numero) {
        if (numero < 1 || numero > 20) {
            return false;
        }

        Asiento asiento = asientos.get(numero - 1);
        if (asiento.estaComprado()) {
            return false;
        }

        asiento.comprar();
        return true;
    }

    public void resetAsientos() {
        for (Asiento asiento : asientos) {
            asiento.setComprado(false);  // Resetea el estado de los asientos a no comprados
        }
    }
}